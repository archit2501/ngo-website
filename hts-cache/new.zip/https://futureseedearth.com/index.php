<!DOCTYPE html>
<html lang="en">

<head>

<!-- ezoic ads -->
 <script src="https://cmp.gatekeeperconsent.com/min.js" data-cfasync="false"></script>
<script src="https://the.gatekeeperconsent.com/cmp.min.js" data-cfasync="false"></script>
<script async src="//www.ezojs.com/ezoic/sa.min.js"></script>
<script>
    window.ezstandalone = window.ezstandalone || {};
    ezstandalone.cmd = ezstandalone.cmd || [];
</script>

  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>FUTURESEED EARTH FOUNDATION - A Seed For Sustainable Development</title>
  <meta content="" name="description">
  <meta
    content="futureseed earth foundation, fsde, fsef, futureseed, earth foundation, future seed earth, futureseedearth, ngo in delhi, ngo, charity, donation, causes, earth foundation india, future seed foundation"
    name="keywords">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <!-- Favicons -->
  <link href="assets/img/cropped-site_logo-1-3.png" rel="icon">
  <link href="assets/img/cropped-site_logo-1-3.png" rel="apple-touch-icon">


  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Roboto:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

<!-- <script>(function(w, d) { w.CollectId = "6142ee58ef0a6c4814d2e40c"; var h = d.head || d.getElementsByTagName("head")[0]; var s = d.createElement("script"); s.setAttribute("type", "text/javascript"); s.async=true; s.setAttribute("src", "https://collectcdn.com/launcher.js"); h.appendChild(s); })(window, document);</script> -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-R61Z2RJQJ9');
</script>
<style>
    .error-message {
      color: red;
      font-size: 0.9em;
      margin-top: 4px;
    }
    .success-message {
      color: green;
      font-size: 1em;
      margin-top: 15px;
    }
  </style>

</head>

<body>
<script>
  // alert('connection successfull');
</script>
  <!-- ======= Top Bar ======= -->

  <section class="topbar">
    <div class="a">
      <div class="_left">
        <div class="contact-info">
          <a target="_blank" href="https://twitter.com/futureseedeart1?t=YQg_MhgIh7MAriKf9kqMrA&s=09" class="twitter"><i
              class="bi bi-twitter"></i></a>
          <a target="_blank" href="https://www.facebook.com/futureseedearthNGO" class="facebook"><i
              class="bi bi-facebook"></i></a>
          <a target="_blank" href="https://www.instagram.com/futureseed_earth_foundation/" class="instagram"><i
              class="bi bi-instagram"></i></a>
          <a target="_blank" href="https://www.linkedin.com/in/futureseed-earth-foundation-84b980212/"
            class="linkedin"><i class="bi bi-linkedin"></i></i></a>
        </div>
      </div>
      <div class="_right">
        <a href="donate.html" class="donate">Donate</a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top" style="top: 3rem;">
    <div class="container d-flex align-items-center">

      <!-- <h1 class="logo me-auto"><a href="index.html"><span>Com</span>pany</a></h1> -->
      <!-- Uncomment below if you prefer to use an image logo -->
      <a href="index.php" class="logo me-auto me-lg-0"><img src="assets/img/cropped-site_logo-1-3.png" alt=""
          class="img-fluid">FUTURESEED EARTH FOUNDATION</a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>

          <li class="dropdown"><a href="#"><span>About</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="about.html">About Us</a></li>
              <li><a href="team.html">Team</a></li>
              <!-- <li><a href="testimonials.html">Testimonials</a></li> -->
              <!-- <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li> -->
            </ul>
          </li>

          <li><a href="services.html">Services</a></li>
          <li><a href="portfolio.html">Products</a></li>
          <li><a href="pricing.html">Events</a></li>
          <li><a href="blog.html">Blog</a></li>
          <li><a href="contact.html">Contact</a></li>

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <!-- <div class="header-social-links d-flex">
        <a href="#" class="twitter"><i class="bu bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bu bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bu bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bu bi-linkedin"></i></i></a>
      </div> -->

    </div>
  </header><!-- End Header -->
<div id="ezoic-pub-ad-placeholder-101"></div>
  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
        <div class="carousel-item active" style="background-image: url(assets/img/banner2.jpg);">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <h2>A Seed For Sustainable Development</h2>
              <p>FSEF promotes sustainable practices and development in various sectors such as Agriculture, Energy, Natural Resources and Water Management. The main goal of FSEF is to Educate and Empower communities to adopt sustainable practices that will help preserve Our Environment and Save Earth. 
 </p>
              <div class="text-center"><a href="about.html" class="btn-get-started">Read More</a></div>
            </div>
          </div>
        </div>

        <!-- Slide 2 -->
        <div class="carousel-item" style="background-image: url(assets/img/plan.jpg);">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <h2>PLANTATION DRIVE</h2>
              <p>Since its establishment in 2019, Futureseed Earth Foundation has been planting saplings and trees. Our main objective is to plant as many plants as we can to make Mother Earth greener and healthier than ever.</p>
              <div class="text-center"><a href="about.html" class="btn-get-started">Read More</a></div>
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image: url(assets/img/bhavti2.jpg);">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <h2>#BHAVTI “Menstrual Hygiene Awareness Drive ”</h2>
              <p>BHAVTI is one of our initiatives, which involves educating schoolgirls and females through campaigns and seminars as well as providing sanitary pads in rural and slum regions. We aim to build up their confidence and teach them healthy habits. Menstrual hygiene is a significant yet frequently disregarded concern in our society. 
.</p>
              <div class="text-center"><a href="about.html" class="btn-get-started">Read More</a></div>
            </div>
          </div>
        </div>

        <!-- Slide 4 -->
        <div class="carousel-item" style="background-image: url(assets/img/HOSLA1.jpg);">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <h2>REGISTERED UNDER SECTION 80G</h2>
              <p>Future Seed Earth Foundation is registered as NGO under Income Tax Act, 1961, 11-Clause (i) of first
                provision to sub-section (5) of section 80G with the Registration Number AADCF8411EF20217.</p>
              <div class="text-center"><a href="about.html" class="btn-get-started">Read More</a></div>
            </div>
          </div>
        </div>
         <!-- Slide 5 -->
         <div class="carousel-item" style="background-image: url(assets/img/banner5.jpg);margin-top: 1.5cm;">
          <div class="carousel-container">
            <div class="carousel-content animate__animated animate__fadeInUp">
              <h2> Food & You 2.0: Make the change</h2>
              <p>Join hands with the Samayu community to reform our food systems and change how we live, eat, love, and share food. We are making this pledge, and so can you.</p>
              <div class="text-center"><a href="https://foodandyou2.com/pledge-page/" class="btn-get-started">Sign up now!</a></div>
            </div>
          </div>
        </div>

      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

    </div>
  </section><!-- End Hero -->
  <div id="ezoic-pub-ad-placeholder-102"></div>

  <main id="main">

    <!-- ======= About Us Section ======= -->
    <!-- <section id="about-us" class="about-us">
      <div class="container" data-aos="fade-up">

        <div class="row content">
          <div class="col-lg-6" data-aos="fade-right">
            <h2>FUTURESEED EARTH FOUNDATION</h2>
            <h3>A Seed For Sustainable Development</h3>
            <hr>
            <div class="event-front">
              <div>
                <h6> <a href="pricing.html">Upcoming Event</a></h6>
                <img src="assets/img/events/24.jpg" alt="">
              </div>
              <div class="eb1">
                <div class="event-info">
                  <p><i class="bi bi-calendar3"></i>&nbsp;01-Aug-2022</p>
                  <p><i class="bi bi-clock"></i>&nbsp;8:00 - 10:00</p>
                  <p><i class="bi bi-geo-alt"></i>&nbsp;New Delhi</p>
                </div>
                <div class="eb">
                  <a target="_blank" class="btn btn-custom"
                    style="background-color: #1bbd36; color: white; width: 100%;"
                    href="https://forms.gle/4iUhKogWWCKegb5q9">Join
                    Now</a>
                </div>
              </div>
              <h4 style="margin-top: 1rem;">Medical Camp</h4>

            </div>
            <hr>
          </div>

          <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
            <p>
              Established in August 2019, Futureseed Earth Foundation is a Non-profit organization which offers
              expertise in multiple fields such as environment welfare, human health and safety,
              women empowerment, underpriviledged children development, agriculture & rural development,
              all through the perspective of research, education & awareness.
            </p>
            <h5>We are Registered Under:</h5>
            <ul>
              <li><i class="ri-check-double-line"></i> Section 80G, Registration Number: AADCF8411EF20217</li>
              <li><i class="ri-check-double-line"></i> Section 12A, Registration Number: AADCF8411EE20219</li>
              <li><i class="ri-check-double-line"></i> NGO Darpan Unique I.D Number: DL/2020/0263102</li>
              <li><i class="ri-check-double-line"></i> Section 8 of the Companies Act, 2013: U85300DL2019NPL354532</li>
            </ul>
            <p class="fst-italic">
              Our planet is precious and only we can save it.
              Reduce, Reuse, Recycle, Plant More Trees & Give Up Plastics
            </p>
          </div>
        </div>

      </div>
    </section> -->
     <section id="about-us" class="about-us">
      <div class="container" data-aos="fade-up">

        <div class="row content">
          <div class="col-lg-6" data-aos="fade-right">
            <h2>FUTURESEED EARTH FOUNDATION</h2>
            <h3>A Seed For Sustainable Development</h3>
            <hr>
 <script>
  // alert('connection successfull');
</script>
 


            <div class="event-front">
              <div>
                
                <h6> <a href="pricing.php">Upcoming Event</a></h6>
               <img src="assets/img/jpg_20230210_130845_0000.jpg" alt="" style="width: 7cm;height: 7cm;">
              </div>
              <div class="eb1">
                <div class="event-info">
                  <p><i class="bi bi-calendar3"></i>&nbsp;2023-02-10</p>
                  <p><i class="bi bi-clock"></i>&nbsp;14:03</p>
                  <p><i class="bi bi-geo-alt"></i>&nbsp;All over the INDIA ( Throughout The Year)</p>
                </div>
                <div class="eb">
                  <a target="_blank" class="btn btn-custom"
                    style="background-color: #1bbd36; color: white; width: 100%;"
                    href="https://docs.google.com/forms/d/1VR_pw1tUSsTR--AvvXRpS-Jc0_DFzoBH3D8eU33hGnI/edit">Join
                    Now</a>
                </div>
              </div>
              <h4 style="margin-top: 1rem;">BHAVTI   (Menstrual Hygiene Drive)</h4>

            </div>

 

            <hr>
          </div>

          <div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-left">
            <p>
              Established in August 2019, Futureseed Earth Foundation is a Non-profit organization which offers
              expertise in multiple fields such as environment welfare, human health and safety,
              women empowerment, underpriviledged children development, agriculture & rural development,
              all through the perspective of research, education & awareness.
            </p>
           
            <h5>We are Registered Under:</h5>
            <ul>
              <li><i class="ri-check-double-line"></i> Section 80G, Registration Number: AADCF8411EF20217</li>
              <li><i class="ri-check-double-line"></i> Section 12A, Registration Number: AADCF8411EE20219</li>
              <li><i class="ri-check-double-line"></i> NGO Darpan Unique I.D Number: DL/2020/0263102</li>
              <li><i class="ri-check-double-line"></i> Section 8 of the Companies Act, 2013: U85300DL2019NPL354532</li>
            </ul>
            <p class="fst-italic">
              Our planet is precious and only we can save it.
              Reduce, Reuse, Recycle, Plant More Trees & Give Up Plastics
            </p>
            <div>
              <img src="assets/img/banner1.png"/>
              <div  style="padding-left:10cm;margin-top: -50px;z-index: 999999;position:center;">
              <button style="background-color: beige;border-radius: 10px;width: 5cm;height: 1cm;"><a href="https://foodandyou2.com/pledge-page/">Sign up now!</a></button></div>
            </div>
          </div>
        </div>

      </div>
    </section>
    <!-- End About Us Section -->

<div id="ezoic-pub-ad-placeholder-103"></div>



    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row counters">

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="10000" data-purecounter-duration="1.5"
              class="purecounter"></span>
            <p>TREE PLANTED</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="20000" data-purecounter-duration="2.4"
              class="purecounter"></span>
            <p>FOOD PACKET DISTRIBUTED</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="24530" data-purecounter-duration="2.7"
              class="purecounter"></span>
            <p>MASKS DISTRIBUTED</p>
          </div>

          <div class="col-lg-3 col-6 text-center">
            <span data-purecounter-start="0" data-purecounter-end="10486" data-purecounter-duration="2"
              class="purecounter"></span>
            <p>SANITARY NAPKINS DISTRIBUTED</p>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->



    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-8 entries">

            <article class="entry">

              <div class="entry-img">
                <!-- <img src="assets/img/blog/blog-1.jpg" alt="" class="img-fluid"> -->
                <video class="img-fluid" src="assets/videos/plantation (1).mp4" autoplay="" loop="" muted="muted"
                  playsinline="" controlsList="nodownload"></video>
              </div>

              <h2 class="entry-title">
                <a href="blog-single.html">PLANTATION DRIVE</a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a
                      href="blog-single.html">Abhishek</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-single.html"><time
                        datetime="2020-01-01">Jan 1, 2020</time></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <a href="blog-single.html">12
                      Comments</a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  <!--FSEF has been planting tree saplings for the last two years now. It is our primary goal to plant as-->
                  <!--many plants as possible,-->
                  <!--so as to make our mother Earth greener and healthier than ever.-->
                  Prior to its establishment in 2019, FSEF has been planting saplings and trees. Our main objective is to plant as many plants as we can to make Mother Earth greener and healthier than ever.

                </p>
                <div class="read-more">
                  <a href="blog-single.html">Read More</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            <article class="entry">

              <div class="entry-img">
                <!-- <img src="assets/img/blog/blog-2.jpg" alt="" class="img-fluid"> -->
                <video class="img-fluid" src="assets/videos/Video_185427_060322.mp4" autoplay="" loop="" muted="muted"
                  playsinline="" controlsList="nodownload"></video>
              </div>

              <h2 class="entry-title">
                <a href="bhavati_blog.html">
                    <!--BHAVTI: Free sanitary napkins distribution-->
                   #BHAVTI “Menstrual Hygiene Awareness Drive ”

                    </a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a
                      href="blog-single.html">Abhishek</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-single.html"><time
                        datetime="2020-01-01">Jan 1, 2020</time></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <a href="blog-single.html">12
                      Comments</a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  <!--FSEF is running a program called BHAVTI wherein we distribute free sanitary pads to-->
                  <!--underprivileged girls and ladies in the slums and rural areas. our aim is to empower them and teach-->
                  <!--them healthy practices.-->
                  <b>BHAVTI</b> is a menstrual hygiene awareness and sanitary napkin drive that is organized by FSEF to promote menstrual hygiene and provide access to sanitary napkins for women and girls. The initiative aims to break the taboo surrounding menstruation and educate women and girls about menstrual hygiene and the importance of using safe and clean menstrual products. The drive also distributes sanitary napkins to low-income and marginalized communities, who otherwise may not have access to these products. <b>BHAVTI</b> also works to empower women and girls through education and awareness campaigns, so they can take control of their menstrual health and hygiene. The initiative is a crucial step towards achieving gender equality and ensuring that all women and girls have access to the resources they need to manage their menstrual health.
                </p>
                <div class="read-more">
                  <a href="bhavati_blog.html">Read More</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            <article class="entry">

              <div class="entry-img">
                <!-- <img src="assets/img/blog/blog-3.jpg" alt="" class="img-fluid"> -->
                <video class="img-fluid" src="assets/videos/Video_191242_060322.mp4" autoplay="" loop="" muted="muted"
                  playsinline="" controlsList="nodownload"></video>
              </div>

              <h2 class="entry-title">
                <a href="hosla.html">COVID-19 RELIEF HOSLA: (Food donation drive)</a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a
                      href="blog-single.html">Abhishek</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-single.html"><time
                        datetime="2020-01-01">Jan 1, 2020</time></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <a href="blog-single.html">12
                      Comments</a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  During the COVID 19 …. FSEF donated more than 20 thousand food packers to the needy folks in and
                  around Delhi region.
                  we aimed to provide as much as possible to every hungry stomach.
                </p>
                <div class="read-more">
                  <a href="hosla.html">Read More</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            <article class="entry">

              <div class="entry-img">
                <!-- <img src="assets/img/blog/blog-4.jpg" alt="" class="img-fluid"> -->
                <video class="img-fluid" src="assets/videos/Mask.mp4" autoplay="" loop="" muted="muted" playsinline=""
                  controlsList="nodownload"></video>
              </div>

              <h2 class="entry-title">
                <a href="mask.html">MASKS DISTRIBUTION</a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a
                      href="blog-single.html">Abhishek</a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-single.html"><time
                        datetime="2020-01-01">Jan 1, 2020</time></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <a href="blog-single.html">12
                      Comments</a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  In the initial days of corona outbreak, the world had no vaccines and all we knew was corona is
                  contagious & spreads through Air. keeping this thing in mind, we have distributed more thand 20
                  thousand masks to slum dwellers at various places in India including Delhi, Bareilly, rewari,
                  muzaffarpur, meerut.
                </p>
                <div class="read-more">
                  <a href="mask.html">Read More</a>
                </div>
              </div>

            </article><!-- End blog entry -->

            <!-- <div class="blog-pagination">
              <ul class="justify-content-center">
                <li><a href="active">1</a></li>
                <li class="#"><a href="#">2</a></li>
                <li><a href="#">3</a></li>
              </ul>
            </div> -->

          </div><!-- End blog entries list -->

          <div class="col-lg-4">

            <div class="sidebar">

              <h2 class="sidebar-title">Donate and Become a Friend of FUTURESEED EARTH FOUNDATION</h2>
              <p>Alone we can do so little; <br> Together we can do so much.</p>
              <h4><a href="">Donate and show your support. Donations made to “FUTURESEED EARTH FOUNDATION” are exempted
                  u/s 80G of the Income Tax Act.</a></h4>

              <br>

              <h3 class="sidebar-title">Account Details</h3>
              <div class="sidebar-item recent-posts">


                <div class="post-item clearfix">
                  Account Name : <br>
                  <h5>FUTUIRESEED EARTH FOUNDATION</h5>
                </div>

                <div class="post-item clearfix">
                  Account Number :
                  <h5>10200003290831</h5>
                </div>

                <div class="post-item clearfix">
                  Name of Bank :
                  <h5>Bandhan Bank</h5>
                </div>

                <div class="post-item clearfix">
                  Branch Code and Address :
                  <h5>Bandhan Bank, Kirti Nagar Branch, 87/1, Block 2,WHS Kirti Nagar, New Delhi, <br> IN-110015</h5>
                </div>

                <div class="post-item clearfix">
                  IFSC Code :
                  <h5>BDBL0001971</h5>
                </div>

              </div><!-- End sidebar recent posts-->

              <h3 class="sidebar-title">UPI/QR Code</h3>
              <p>Donations can also be made by scanning the QR code displayed on the right hand side in your UPI APP.
              </p>
              <h5 style="color: #00a2e8;">UPI ID- Q03333538@ybl</h5>
              <div class="sidebar-item categories">
                <img src="assets/img/upi.png" alt="">
              </div><!-- End upi categories-->

              <div>**After making the donation, Please fill this form for the donor certificate.</div>
              <br><br>

              <h3 class="sidebar-title">Donation to "FUTURESEED EARTH FOUNDATION"</h3>
              <p>Please fill below form after making a donation to us. Certificate will be sent over email.</p>

              <div class="donor_form">
                <!-- https://formspree.io/f/xbjwedpz -->
                <form id="donationForm" action="donationform.php" method="POST" enctype="multipart/form-data" novalidate>
      
      <div class="mb-3">
        <input type="text" name="Full_Name" class="form-control" placeholder="Your Full Name" />
        <div class="error-message " id="error-name"></div>
      </div>

      <div class="mb-3">
        <input type="email" name="Email_Address" class="form-control" placeholder="Your Email Address" />
        <div class="error-message" id="error-email"></div>
      </div>

      <div class="mb-3">
        <input type="text" name="Mobile_Number" class="form-control" placeholder="Your Contact Number" />
        <div class="error-message" id="error-phone"></div>
      </div>

      <div class="mb-3">
        <input type="text" name="Amount_Donated" class="form-control" placeholder="Amount Donated" />
        <div class="error-message" id="error-amount"></div>
      </div>

      <div class="mb-3">
        <input type="text" name="Home_Address" class="form-control" placeholder="Your Address" />
      </div>

      <div class="mb-3">
        <input type="file" name="Screenshot" class="form-control" />
        <div class="error-message" id="error-file"></div>
      </div>

      <div class="mb-3">
        <textarea name="Message" class="form-control" rows="4" placeholder="Any Message For Us..."></textarea>
      </div>

      <div class="text-center">
        <button type="submit" class="btn btn-success px-5">Submit</button>
      </div>

      <div id="formSuccess" class="alert alert-success mt-4 d-none">
        ✅ Thank you! Your donation has been submitted successfully.
      </div>
      <div id="formError" class="alert alert-danger mt-3 d-none">
        ❌ Please fix the errors and try again.
      </div>
    </form>

              </div>
              <!-- End sidebar tags-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->


        </div>

      </div>
    </section><!-- End Blog Section -->

<div id="ezoic-pub-ad-placeholder-104"></div>


    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">
        <div class="section-title" data-aos="fade-up">
          <h2>Our <strong>Services</strong></h2>
        </div>
        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box iconbox-blue">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5"
                    d="M300,521.0016835830174C376.1290562159157,517.8887921683347,466.0731472004068,529.7835943286574,510.70327084640275,468.03025145048787C554.3714126377745,407.6079735673963,508.03601936045806,328.9844924480964,491.2728898941984,256.3432110539036C474.5976632858925,184.082847569629,479.9380746630129,96.60480741107993,416.23090153303,58.64404602377083C348.86323505073057,18.502131276798302,261.93793281208167,40.57373210992963,193.5410806939664,78.93577620505333C130.42746243093433,114.334589627462,98.30271207620316,179.96522072025542,76.75703585869454,249.04625023123273C51.97151888228291,328.5150500222984,13.704378332031375,421.85034740162234,66.52175969318436,486.19268352777647C119.04800174914682,550.1803526380478,217.28368757567262,524.383925680826,300,521.0016835830174">
                  </path>
                </svg>
                <i class="bi bi-tree-fill"></i>
              </div>
              <h4><a href="/environmental-research.html">Environmental (Research & Education)</a></h4>
              <p>We have conducted various Webinars, Seminar, and Workshops in the field of Environment &
                Sustainability.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in"
            data-aos-delay="200">
            <div class="icon-box iconbox-orange ">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5"
                    d="M300,521.0016835830174C376.1290562159157,517.8887921683347,466.0731472004068,529.7835943286574,510.70327084640275,468.03025145048787C554.3714126377745,407.6079735673963,508.03601936045806,328.9844924480964,491.2728898941984,256.3432110539036C474.5976632858925,184.082847569629,479.9380746630129,96.60480741107993,416.23090153303,58.64404602377083C348.86323505073057,18.502131276798302,261.93793281208167,40.57373210992963,193.5410806939664,78.93577620505333C130.42746243093433,114.334589627462,98.30271207620316,179.96522072025542,76.75703585869454,249.04625023123273C51.97151888228291,328.5150500222984,13.704378332031375,421.85034740162234,66.52175969318436,486.19268352777647C119.04800174914682,550.1803526380478,217.28368757567262,524.383925680826,300,521.0016835830174">
                  </path>
                </svg>
                <i class="bi bi-activity"></i>
              </div>
              <h4><a href="/peoples-health.html">People's Health (Research, Education & Awareness)</a></h4>
              <p>FSEF conducts awareness programs at various locations in collaboration with other organizations to
                aware as many people as possible about the People’s health.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in"
            data-aos-delay="300">
            <div class="icon-box iconbox-pink">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5"
                    d="M300,541.5067337569781C382.14930387511276,545.0595476570109,479.8736841581634,548.3450877840088,526.4010558755058,480.5488172755941C571.5218469581645,414.80211281144784,517.5187510058486,332.0715597781072,496.52539010469104,255.14436215662573C477.37192572678356,184.95920475031193,473.57363656557914,105.61284051026155,413.0603344069578,65.22779650032875C343.27470386102294,18.654635553484475,251.2091493199835,5.337323636656869,175.0934190732945,40.62881213300186C97.87086631185822,76.43348514350839,51.98124368387456,156.15599469081315,36.44837278890362,239.84606092416172C21.716077023791087,319.22268207091537,43.775223500013084,401.1760424656574,96.891909868211,461.97329694683043C147.22146801428983,519.5804099606455,223.5754009179313,538.201503339737,300,541.5067337569781">
                  </path>
                </svg>
                <i class="bi bi-people-fill"></i>
              </div>
              <h4><a href="/csr.html">CSR (Implementation)</a></h4>
              <p>CSR is a major tool for corporate bodies to give back to society and nature from which they have gained
                soo much. We at FSEF also provide consultancy in implementation of CSR fund especially in the field of
                Environment & Sustainability.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box iconbox-yellow">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5"
                    d="M300,503.46388370962813C374.79870501325706,506.71871716319447,464.8034551963731,527.1746412648533,510.4981551193396,467.86667711651364C555.9287308511215,408.9015244558933,512.6030010748507,327.5744911775523,490.211057578863,256.5855673507754C471.097692560561,195.9906835881958,447.69079081568157,138.11976852964426,395.19560036434837,102.3242989838813C329.3053358748298,57.3949838291264,248.02791733380457,8.279543830951368,175.87071277845988,42.242879143198664C103.41431057327972,76.34704239035025,93.79494320519305,170.9812938413882,81.28167332365135,250.07896920659033C70.17666984294237,320.27484674793965,64.84698225790005,396.69656628748305,111.28512138212992,450.4950937839243C156.20124167950087,502.5303643271138,231.32542653798444,500.4755392045468,300,503.46388370962813">
                  </path>
                </svg>
                <i class="bi bi-recycle"></i>
              </div>
              <h4><a href="/ecosystem-restoration.html">Ecosystem Restoration</a></h4>
              <p>We conduct tree plantation drives throughout the year. We have also pledged to plant 50,0000 sapling in
                the year 2030.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box iconbox-red">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5"
                    d="M300,532.3542879108572C369.38199826031484,532.3153073249985,429.10787420159085,491.63046689027357,474.5244479745417,439.17860296908856C522.8885846962883,383.3225815378663,569.1668002868075,314.3205725914397,550.7432151929288,242.7694973846089C532.6665558377875,172.5657663291529,456.2379748765914,142.6223662098291,390.3689995646985,112.34683881706744C326.66090330228417,83.06452184765237,258.84405631176094,53.51806209861945,193.32584062364296,78.48882559362697C121.61183558270385,105.82097193414197,62.805066853699245,167.19869350419734,48.57481801355237,242.6138429142374C34.843463184063346,315.3850353017275,76.69343916112496,383.4422959591041,125.22947124332185,439.3748458443577C170.7312796277747,491.8107796887764,230.57421082200815,532.3932930995766,300,532.3542879108572">
                  </path>
                </svg>
                <i class="bi bi-megaphone-fill"></i>
              </div>
              <h4><a href="/awareness-program.html">Awareness Programs</a></h4>
              <p>FSEF conducts awareness programs at various location in collaboration with other organizations to aware
                as many people as possible about the environmental health.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box iconbox-teal">
              <div class="icon">
                <svg width="100" height="100" viewBox="0 0 600 600" xmlns="http://www.w3.org/2000/svg">
                  <path stroke="none" stroke-width="0" fill="#f5f5f5"
                    d="M300,566.797414625762C385.7384707136149,576.1784315230908,478.7894351017131,552.8928747891023,531.9192734346935,484.94944893311C584.6109503024035,417.5663521118492,582.489472248146,322.67544863468447,553.9536738515405,242.03673114598146C529.1557734026468,171.96086150256528,465.24506316201064,127.66468636344209,395.9583748389544,100.7403814666027C334.2173773831606,76.7482773500951,269.4350130405921,84.62216499799875,207.1952322260088,107.2889140133804C132.92018162631612,134.33871894543012,41.79353780512637,160.00259165414826,22.644507872594943,236.69541883565114C3.319112789854554,314.0945973066697,72.72355303640163,379.243833228382,124.04198916343866,440.3218312028393C172.9286146004772,498.5055451809895,224.45579914871206,558.5317968840102,300,566.797414625762">
                  </path>
                </svg>
                <i class="bi bi-flower3"></i>
              </div>
              <h4><a href="/renewable-energy.html">Renewable Sources Of Energy</a></h4>
              <p>We are working towards to promote the Renewable Sources of Energy and save our mother planet from the
                curse of
                climate change, global worming and pollution.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
    <section>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <h1 class="text-center mb-5">Our Supporters</h1>
            <div class="slider">
  <div class="slide-track">
  <div class="slide">
      <img src="assets/img/Our Supporters/supporter10.jpg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporter11.jpg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporter12.jpg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters1.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters2.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporter11.jpg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters3.jpeg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters4.jpeg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters5.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporter10.jpg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters6.jpeg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters7.jpeg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters8.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters9.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters10.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters1.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters2.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters3.jpeg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters4.jpeg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters5.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters6.jpeg" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters7.png" alt="">
    </div>
    <div class="slide">
      <img src="assets/img/Our Supporters/supporters8.png" alt="">
    </div>
    
  </div>
</div>
          </div>
        </div>
      </div>
    </section>

</div>
    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container">
        <div class="section-title" data-aos="fade-up">
          <h2>Products For <strong>Donation</strong></h2>
        </div>
        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">VRAKSHAM</li>
              <li data-filter=".filter-card">BHAVTI</li>
              
            </ul>
          </div>
        </div>
        <div class="">
       <div class="row portfolio-container" data-aos="fade-up">

          <!-- ======================== -->
          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/productvart1.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>ADOPT A PLANT WITH US</h4>
              <p>(151-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/1.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="ADOPT A PLANT WITH US"><i class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div>

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/4.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>DONATE 1 MONTH SANITARY NAPKINS</h4>
              <p>(201-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/portfolio-2.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="Web 3"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div> -->

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/productvart2.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>ADOPT 50 PLANT WITH US</h4>
              <p>(2000-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/2.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="ADOPT 50 PLANT WITH US"><i class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/productbhavti1.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>DONATE 1 MONTHS SANITARY NAPKINS</h4>
              <p>(201-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/5.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="DONATE 1 MONTHS SANITARY NAPKINS"><i
                  class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div>

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/5.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>DONATE 3 MONTHS SANITARY NAPKINS</h4>
              <p>(501-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/portfolio-5.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="Web 2"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div> -->

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/productvart3.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>ADOPT 100 PLANT WITH US</h4>
              <p>(3500-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/3.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="ADOPT 100 PLANT WITH US"><i class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/productbhavti3.jpeg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>DONATE 3 MONTH SANITARY NAPKINS</h4>
              <p>(501-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/4.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="DONATE 3 MONTH SANITARY NAPKINS"><i
                  class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div>

        <!--   <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/7.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>MONEY PLANT</h4>
              <p>(800-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/7.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="MONEY PLANT"><i class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div> -->

         <!--  <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/8.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>SANSEVIERIA</h4>
              <p>(800-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/8.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="SANSEVIERIA"><i class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div> -->

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <img src="assets/img/portfolio/productbhavti2.jpeg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>DONATE 1 YEAR SANITARY NAPKINS</h4>
              <p>(2100-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/6.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="DONATE 1 YEAR SANITARY NAPKINS"><i
                  class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div>

        <!--   <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <img src="assets/img/portfolio/9.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>ARECA PALM</h4>
              <p>(800-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/9.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="ARECA PALM"><i class="bx bx-plus"></i></a>
              <a href="https://wa.me/918700229846" target="_blank" class="details-link" title="More Details"><i
                  class="bx bx-link"></i></a>
            </div>
          </div> -->

          <!-- <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <img src="assets/img/portfolio/6.jpg" class="img-fluid" alt="">
            <div class="portfolio-info">
              <h4>DONATE 1 YEAR SANITARY NAPKINS</h4>
              <p>(2100-/ R.s ONLY)</p>
              <a href="assets/img/portfolio/portfolio-9.jpg" data-gallery="portfolioGallery"
                class="portfolio-lightbox preview-link" title="Web 3"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" class="details-link" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div> -->

        </div>

      </div>
    </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Our Clients Section ======= -->
    <!-- <section id="clients" class="clients">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Clients</h2>
        </div>

        <div class="row no-gutters clients-wrap clearfix" data-aos="fade-up">

          <div class="col-lg-3 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-2.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-4.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-5.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-6.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-7.png" class="img-fluid" alt="">
            </div>
          </div>

          <div class="col-lg-3 col-md-4 col-6">
            <div class="client-logo">
              <img src="assets/img/clients/client-8.png" class="img-fluid" alt="">
            </div>
          </div>

        </div>

      </div>
    </section>End Our Clients Section -->

  </main><!-- End #main -->

  <!-- whatsapp chat start -->

  <div id="#" class="whatsapp_float">
    <a href="https://wa.me/918700229846" target="_blank">
      <i class="bi bi-whatsapp"></i>
    </a>
  </div>

  <!-- whatsapp chat end -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>FUTURESEED EARTH FOUNDATION</h3>
            <p>
              40, L Extension Part-2, <br>
              Mohan Garden, Uttam Nagar,<br>
              New Delhi- 110059 <br><br>
              <strong>Phone:</strong> 8700229846, 9555535758, 9599043000, 9456385958<br>
              <strong>Email:</strong> futureseedearth@outlook.com, futureseedearth2019@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="index.php">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="about.html">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="services.html">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="assets/Introduction to FSEF.pdf"
                  download="Introduction to FSFE">Downloads</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="login.html">Admin</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
                        <h4>Our Services</h4>
                        <ul>
                            <li><i class="bx bx-chevron-right"></i> <a href="environmental-research.html">Environmental</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="peoples-health.html">People's Health</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="csr.html">CSR</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="ecosystem-restoration.html">Ecosystem Restoration</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="awareness-program.html">Awareness Programs</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="renewable-energy.html">Renewable Energy</a></li>
                        </ul>
                    </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>Subscribe and get updated about our latest events and news.</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>FSDE</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          Designed by <a target="_blank" href="https://www.bridgegroupsolutions.com/">Bridge Group Solutions</a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a target="_blank" href="https://twitter.com/futureseedeart1?t=YQg_MhgIh7MAriKf9kqMrA&s=09" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a target="_blank" href="https://www.facebook.com/futureseedearthNGO" class="facebook"><i
            class="bx bxl-facebook"></i></a>
        <a target="_blank" href="https://www.instagram.com/futureseed_earth_foundation/" class="instagram"><i
            class="bx bxl-instagram"></i></a>
        <a target="_blank" href="https://www.youtube.com/channel/UC_Y0wy5N2js4C-Xtokxpnhw/featured"
          class="google-plus"><i class="bi bi-youtube"></i></a>
        <a target="_blank" href="https://www.linkedin.com/in/futureseed-earth-foundation-84b980212/" class="linkedin"><i
            class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->


  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>


  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/js/count.js"></script>
 <!--  <style type="text/css">
    .lilogo{
      display: contents;
    }
    .lilogo img{
       vertical-align: middle;
  max-width: 100%;
  width:150px;
  max-height: 100%;
  -webkit-transition: 0 linear left;
  -moz-transition: 0 linear left;
  transition: 0 linear left;
    }
  #ourclients {
  display: block;
  margin-left: auto;
  margin-right: auto;
  background:#f9f9f9;
  padding-bottom:30px;
  height:150px;
}
#ourclients .clients-wrap {
  display: block;
  width: 95%;
  margin: 0 auto;
  overflow: hidden;
}
#ourclients .clients-wrap ul {
  display: block;
  list-style: none;
  position: relative;
  margin-left: auto;
  margin-right: auto;
}
#ourclients .clients-wrap ul li {
  display: block;
  float: left;
  position: relative;
  width: 220px;
  height: 100px;
  line-height: 100px;
  text-align: center;
}
#ourclients .clients-wrap ul li img {
  vertical-align: middle;
  max-width: 100%;
  width:150px;
  max-height: 100%;
  -webkit-transition: 0 linear left;
  -moz-transition: 0 linear left;
  transition: 0 linear left;
}
#ourclients h3{
border-bottom:2px solid #3399ff;
width:150px;
padding:10px;
}
</style>
<script type="text/javascript">
  $(function() {
  var $clientslider = $('#clientlogo');
  var clients = $clientslider.children().length;
  var clientwidth = (clients * 220); 
  $clientslider.css('width', clientwidth);
  var rotating = true;
  var clientspeed = 1800;
  var seeclients = setInterval(rotateClients, clientspeed);
  $(document).on({
    mouseenter: function() {
      rotating = false;
    },
    mouseleave: function() {
      rotating = true;
    }
  }, '#ourclients');
  function rotateClients() {
    if (rotating != false) {
      var $first = $('#clientlogo li:first');
      $first.animate({
        'margin-left': '-220px'
      }, 2000, function() {
        $first.remove().css({
          'margin-left': '0px'
        });
        $('#clientlogo li:last').after($first);
      });
    }
  }
});
</script> -->

<!-- Run all ad placeholders together -->
  <script>
    ezstandalone.cmd.push(function () {
      ezstandalone.showAds(101, 102, 103, 104);
    });
  </script>
   <script>
    document.getElementById('donationForm').addEventListener('submit', function (e) {
      e.preventDefault();

      let valid = true;
      const form = e.target;

      const name = form.Full_Name.value.trim();
      const email = form.Email_Address.value.trim();
      const phone = form.Mobile_Number.value.trim();
      const amount = form.Amount_Donated.value.trim();
      const file = form.Screenshot.value;

      // Reset all error messages
      document.querySelectorAll('.error-message').forEach(el => el.innerText = '');
      document.getElementById('formSuccess').classList.add('d-none');
      document.getElementById('formError').classList.add('d-none');

      // Validation
      if (name === "") {
        document.getElementById('error-name').innerText = "Full name is required.";
        valid = false;
      }

      if (email === "" || !/^\S+@\S+\.\S+$/.test(email)) {
        document.getElementById('error-email').innerText = "Valid email is required.";
        valid = false;
      }

      if (phone === "" || !/^\d{10,15}$/.test(phone)) {
        document.getElementById('error-phone').innerText = "Valid contact number is required.";
        valid = false;
      }

      if (amount === "" || isNaN(amount)) {
        document.getElementById('error-amount').innerText = "Valid amount is required.";
        valid = false;
      }

      if (file === "") {
        document.getElementById('error-file').innerText = "Screenshot is required.";
        valid = false;
      }

      if (!valid) {
        document.getElementById('formError').classList.remove('d-none');
        return;
      }

      // If valid, proceed to submit the form
      const formData = new FormData(form);

      fetch(form.action, {
        method: 'POST',
        body: formData
      })
      .then(res => res.text())
      .then(response => {
        // You can change this based on your PHP response
        if (response.toLowerCase().includes("success")) {
          document.getElementById('formSuccess').classList.remove('d-none');
          form.reset();
        } else {
          document.getElementById('formError').innerText = "❌ Failed to send. Please try again later.";
          document.getElementById('formError').classList.remove('d-none');
        }
      })
      .catch(() => {
        document.getElementById('formError').innerText = "❌ Network error. Please try again.";
        document.getElementById('formError').classList.remove('d-none');
      });
    });
  </script>
</body>


</html>